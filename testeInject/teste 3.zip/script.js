define(['jquery'], function ($) {
  var CustomWidget = function () {
    var self = this;

    // ========= Helpers =========
    function getCfg() {
      var s = self.get_settings ? (self.get_settings() || {}) : {};
      return {
        bolo_enabled: !!s.bolo_enabled,
        entrevista_enabled: !!s.entrevista_enabled,
        tarefa_enabled: !!s.tarefa_enabled,
        token: s.api_token || '',
        login: s.login || ''
      };
    }

    function saveCfg(partial) {
      var current = self.get_settings ? (self.get_settings() || {}) : {};
      var payload = Object.assign({}, current, partial || {});
      if (typeof self.save_settings === 'function') self.save_settings(payload);
      if (window.AMOCRM && AMOCRM.notifications) {
        AMOCRM.notifications.show_message({
          header: 'Configurações salvas',
          text: 'Preferências atualizadas com sucesso.',
          date: new Date()
        });
      }
      return payload;
    }

    // ========= HTML da página advanced_settings =========
    function htmlAdvanced() {
      return `
        <div id="widget-advanced-root" class="kembed">
          <style>
            .kembed{font-family:Inter,system-ui,Segoe UI,Roboto,Arial,sans-serif;color:#101828}
            .kembed .panel{max-width:980px;margin:0 auto;padding:8px 0}
            .kembed .topbar{display:flex;justify-content:flex-end;gap:8px;margin-bottom:16px}
            .kembed .btn{padding:10px 14px;border:none;border-radius:10px;font-weight:600;cursor:pointer;transition:.15s}
            .kembed .btn--primary{background:#2b7cff;color:#fff}
            .kembed .btn--primary:hover{background:#1f5ec4}
            .kembed .btn--secondary{background:#f5f5f7;color:#222;border:1px solid #e6e8ee}
            .kembed .grid{display:grid;gap:16px}
            @media(min-width:900px){.kembed .grid{grid-template-columns:1fr 1fr}}
            .kembed .card{background:#fff;border:1px solid #e6e8ee;border-radius:14px;padding:18px;display:flex;flex-direction:column;gap:10px}
            .kembed .card h3{margin:0;font-size:16px;line-height:1.2}
            .kembed .desc{color:#475467;font-size:13px;line-height:1.55}
            .kembed .switch{display:inline-flex;align-items:center;gap:10px;user-select:none}
            .kembed .switch input{display:none}
            .kembed .slider{position:relative;width:46px;height:26px;background:#e5e7eb;border-radius:999px;transition:.2s}
            .kembed .switch input:checked + .slider{background:#2b7cff}
            .kembed .switch input:checked + .slider::after{transform:translateX(20px)}
            .kembed .footer{margin-top:16px;display:flex;justify-content:flex-end;gap:10px}
          </style>

          <div class="panel">
            <div class="topbar">
              <button type="button" class="btn btn--secondary" id="btn_restaurar">Restaurar padrão</button>
              <button type="button" class="btn btn--primary" id="btn_salvar">Salvar configurações</button>
            </div>

            <div class="grid">
              <div class="card">
                <div class="switch">
                  <label><input type="checkbox" id="toggle_bolo"><span class="slider"></span></label>
                  <strong>Automação “Bolo”</strong>
                </div>
                <h3>Identificar e mover leads que faltaram à visita</h3>
                <p class="desc">Verifica leads que não compareceram e move para “bolo”, criando tarefa de follow-up.</p>
              </div>

              <div class="card">
                <div class="switch">
                  <label><input type="checkbox" id="toggle_entrevista"><span class="slider"></span></label>
                  <strong>Atualização automática da data/hora da entrevista</strong>
                </div>
                <h3>Sincronizar “entrevista realizada”</h3>
                <p class="desc">Ao marcar realizada conforme previsto, atualiza o campo de data/hora efetiva.</p>
              </div>

              <div class="card">
                <div class="switch">
                  <label><input type="checkbox" id="toggle_tarefa"><span class="slider"></span></label>
                  <strong>Criar tarefa ao criar novo lead</strong>
                </div>
                <h3>Gatilho de primeiro contato</h3>
                <p class="desc">Sempre que um novo lead for criado, gera tarefa automática para atendimento rápido.</p>
              </div>
            </div>

            <div class="footer">
              <button type="button" class="btn btn--secondary" id="btn_restaurar_b">Restaurar padrão</button>
              <button type="button" class="btn btn--primary" id="btn_salvar_b">Salvar configurações</button>
            </div>
          </div>
        </div>
      `;
    }

    // ========= Injeção (estrutura do modelo) =========
    function findContainer() {
      if (self.$container && self.$container.length) return self.$container;
      var sel = [
        '.widget_settings_block__body',
        '.widget-settings__body',
        '.widget_settings__body',
        '.settings__page-body',
        '#widget_settings__content'
      ];
      for (var i = 0; i < sel.length; i++) {
        var $c = $(sel[i]);
        if ($c.length) return $c;
      }
      return $('body'); // fallback extremo
    }

    // mount com logs e retorno booleano
    function mount() {
      var t0 = Date.now();
      try {
        var $c = findContainer();
        if (!$c || !$c.length) {
          console.warn('[Widget] mount: container NÃO encontrado.');
          return false;
        }
        $c.find('#widget-advanced-root').remove();
        $c.html(htmlAdvanced());

        var ok = !!document.getElementById('widget-advanced-root');
        if (!ok) {
          console.error('[Widget] mount: HTML NÃO foi inserido no DOM.');
          return false;
        }

        // estado inicial dos toggles
        var c = getCfg();
        $('#toggle_bolo').prop('checked', c.bolo_enabled);
        $('#toggle_entrevista').prop('checked', c.entrevista_enabled);
        $('#toggle_tarefa').prop('checked', c.tarefa_enabled);

        // handlers
        $(document).off('click.widgetadv', '#btn_salvar, #btn_salvar_b')
                   .on('click.widgetadv', '#btn_salvar, #btn_salvar_b', function(){
                      var novo = {
                        bolo_enabled: $('#toggle_bolo').is(':checked'),
                        entrevista_enabled: $('#toggle_entrevista').is(':checked'),
                        tarefa_enabled: $('#toggle_tarefa').is(':checked')
                      };
                      saveCfg(novo);
                   });
        $(document).off('click.widgetadv', '#btn_restaurar, #btn_restaurar_b')
                   .on('click.widgetadv', '#btn_restaurar, #btn_restaurar_b', function(){
                      $('#toggle_bolo,#toggle_entrevista,#toggle_tarefa').prop('checked', false);
                   });

        console.info('[Widget] mount: render OK em %dms (container=%s)',
          Date.now() - t0, $c.get(0)?.className || $c.get(0)?.id || $c.get(0)?.nodeName);
        return true;
      } catch (e) {
        console.error('[Widget] mount: erro durante render ->', e);
        return false;
      }
    }

    // ========= Callbacks =========
    this.callbacks = {
      init: function () { return true; },

      // callback oficial da página advanced_settings
      advancedSettings: function () {
        var t0 = Date.now();
        var ok = false;
        try {
          ok = mount();
        } catch (e) {
          console.error('[Widget] advancedSettings: exceção ao montar ->', e);
        } finally {
          var dt = Date.now() - t0;
          if (ok) {
            console.log('[Widget] advancedSettings: render SUCESSO (%dms)', dt);
          } else {
            console.warn('[Widget] advancedSettings: render FALHOU (%dms). Verifique seletor do container e HTML.', dt);
            if (window.AMOCRM?.notifications) {
              AMOCRM.notifications.show_message({
                header: 'Falha ao renderizar',
                text: 'Não foi possível montar a tela avançada. Veja o console (F12).',
                date: new Date()
              });
            }
          }
        }
        return true;
      },

      // fallback defensivo: se por algum motivo a área vier como advanced_settings aqui
      render: function () {
        try {
          var area = (self.system && typeof self.system === 'function') ? self.system().area : null;
          if (area === 'advanced_settings') {
            var ok = mount();
            console[ok ? 'log' : 'warn']('[Widget] render(advanced_settings): %s', ok ? 'OK' : 'FALHOU');
          }
        } catch (e) {
          console.error('[Widget] render: erro ->', e);
        }
        return true;
      },

      bind_actions: function () { return true; },
      settings: function () { return true; },
      onSave: function () { return true; },

      destroy: function () {
        $(document).off('.widgetadv');
      }
    };

    return this;
  };

  return CustomWidget;
});
