define(['jquery'], function ($) {
  var CustomWidget = function () {
    var self = this;

    // ===== Helpers =====
    function getCfg() {
      var s = self.get_settings ? (self.get_settings() || {}) : {};
      return {
        bolo_enabled: !!s.bolo_enabled,
        entrevista_enabled: !!s.entrevista_enabled,
        tarefa_enabled: !!s.tarefa_enabled,
        token: s.api_token || '',
        login: s.login || ''
      };
    }
    function saveCfg(partial) {
      var current = self.get_settings ? (self.get_settings() || {}) : {};
      var payload = Object.assign({}, current, partial || {});
      if (typeof self.save_settings === 'function') self.save_settings(payload);
      if (window.AMOCRM && AMOCRM.notifications) {
        AMOCRM.notifications.show_message({
          header: 'Configurações salvas',
          text: 'Preferências atualizadas com sucesso.',
          date: new Date()
        });
      }
      return payload;
    }

    // ===== HTML da página advanced_settings =====
    function htmlAdvanced() {
      return `
        <div id="widget-advanced-root" class="kembed">
          <style>
            .kembed{font-family:Inter,system-ui,Segoe UI,Roboto,Arial,sans-serif;color:#101828}
            .kembed .panel{max-width:980px;margin:0 auto;padding:8px 0}
            .kembed .topbar{display:flex;justify-content:flex-end;gap:8px;margin-bottom:16px}
            .kembed .btn{padding:10px 14px;border:none;border-radius:10px;font-weight:600;cursor:pointer;transition:.15s}
            .kembed .btn--primary{background:#2b7cff;color:#fff}
            .kembed .btn--primary:hover{background:#1f5ec4}
            .kembed .btn--secondary{background:#f5f5f7;color:#222;border:1px solid #e6e8ee}
            .kembed .grid{display:grid;gap:16px}
            @media(min-width:900px){.kembed .grid{grid-template-columns:1fr 1fr}}
            .kembed .card{background:#fff;border:1px solid #e6e8ee;border-radius:14px;padding:18px;display:flex;flex-direction:column;gap:10px}
            .kembed .card h3{margin:0;font-size:16px;line-height:1.2}
            .kembed .desc{color:#475467;font-size:13px;line-height:1.55}
            .kembed .switch{display:inline-flex;align-items:center;gap:10px;user-select:none}
            .kembed .switch input{display:none}
            .kembed .slider{position:relative;width:46px;height:26px;background:#e5e7eb;border-radius:999px;transition:.2s}
            .kembed .slider::after{content:"";position:absolute;top:3px;left:3px;width:20px;height:20px;background:#fff;border-radius:50%;transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.15)}
            .kembed .switch input:checked + .slider{background:#2b7cff}
            .kembed .switch input:checked + .slider::after{transform:translateX(20px)}
            .kembed .footer{margin-top:16px;display:flex;justify-content:flex-end;gap:10px}
          </style>

          <div class="panel">
            <div class="topbar">
              <button type="button" class="btn btn--secondary" id="btn_restaurar">Restaurar padrão</button>
              <button type="button" class="btn btn--primary" id="btn_salvar">Salvar configurações</button>
            </div>

            <div class="grid">
              <div class="card">
                <div class="switch">
                  <label><input type="checkbox" id="toggle_bolo"><span class="slider"></span></label>
                  <strong>Automação “Bolo”</strong>
                </div>
                <h3>Identificar e mover leads que faltaram à visita</h3>
                <p class="desc">Verifica leads que não compareceram e move para “bolo”, criando tarefa de follow-up.</p>
              </div>

              <div class="card">
                <div class="switch">
                  <label><input type="checkbox" id="toggle_entrevista"><span class="slider"></span></label>
                  <strong>Atualização automática da data/hora da entrevista</strong>
                </div>
                <h3>Sincronizar “entrevista realizada”</h3>
                <p class="desc">Ao marcar realizada conforme previsto, atualiza o campo de data/hora efetiva.</p>
              </div>

              <div class="card">
                <div class="switch">
                  <label><input type="checkbox" id="toggle_tarefa"><span class="slider"></span></label>
                  <strong>Criar tarefa ao criar novo lead</strong>
                </div>
                <h3>Gatilho de primeiro contato</h3>
                <p class="desc">Sempre que um novo lead for criado, gera tarefa automática para atendimento rápido.</p>
              </div>
            </div>

            <div class="footer">
              <button type="button" class="btn btn--secondary" id="btn_restaurar_b">Restaurar padrão</button>
              <button type="button" class="btn btn--primary" id="btn_salvar_b">Salvar configurações</button>
            </div>
          </div>
        </div>
      `;
    }

    // ===== Injeção (igual ao modelo) =====
    function findContainer() {
      if (self.$container && self.$container.length) return self.$container;
      var sel = [
        '.widget_settings_block__body',
        '.widget-settings__body',
        '.widget_settings__body',
        '.settings__page-body',
        '#widget_settings__content'
      ];
      for (var i = 0; i < sel.length; i++) {
        var $c = $(sel[i]);
        if ($c.length) return $c;
      }
      return $('body'); // fallback extremo
    }

    function mount() {
      var $c = findContainer();
      $c.find('#widget-advanced-root').remove();  // evita duplicar
      $c.html(htmlAdvanced());                    // 👈 forma TODO o DOM da página avançada

      // estado inicial
      var c = getCfg();
      $('#toggle_bolo').prop('checked', c.bolo_enabled);
      $('#toggle_entrevista').prop('checked', c.entrevista_enabled);
      $('#toggle_tarefa').prop('checked', c.tarefa_enabled);

      // handlers
      $(document).off('click.widgetadv', '#btn_salvar, #btn_salvar_b')
                 .on('click.widgetadv', '#btn_salvar, #btn_salvar_b', function(){
                    var novo = {
                      bolo_enabled: $('#toggle_bolo').is(':checked'),
                      entrevista_enabled: $('#toggle_entrevista').is(':checked'),
                      tarefa_enabled: $('#toggle_tarefa').is(':checked')
                    };
                    saveCfg(novo);
                 });
      $(document).off('click.widgetadv', '#btn_restaurar, #btn_restaurar_b')
                 .on('click.widgetadv', '#btn_restaurar, #btn_restaurar_b', function(){
                    $('#toggle_bolo,#toggle_entrevista,#toggle_tarefa').prop('checked', false);
                 });
    }

    // ===== Callbacks =====
    this.callbacks = {
      init: function () { return true; },

      // Modelo oficial: o Kommo chama ESTE callback para a página "advanced_settings"
      advancedSettings: function () {
        mount();
        return true;
      },

      // Mantém os demais vazios/sem injetar nada
      render: function () { return true; },
      bind_actions: function () { return true; },
      settings: function () { return true; },
      onSave: function () { return true; },
      destroy: function () { $(document).off('.widgetadv'); }
    };

    return this;
  };

  return CustomWidget;
});