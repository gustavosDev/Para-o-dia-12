define(['jquery'], function ($) {
  var CustomWidget = function () {
    var self = this;

    // ========= Helpers (opcional) =========
    function getCfg() {
      var s = self.get_settings ? (self.get_settings() || {}) : {};
      return s; // ajuste conforme precisar (ex.: token/login)
    }

    // ========= HTML da aba Advanced =========
    function htmlAdvanced() {
      return `
        <div id="widget-advanced-root">
          <!-- TROQUE ESTE BLOCO PELO SEU HTML -->
          <div style="padding:24px;font-family:Inter,system-ui,Segoe UI,Roboto,Arial,sans-serif">
            <h2 style="margin:0 0 12px">Minha tela avançada</h2>
            <p>Conteúdo da aba <b>advanced_settings</b> renderizado automaticamente.</p>
          </div>
        </div>
      `;
    }

    // ========= Injeção (igual ao modelo) =========
    function findContainer() {
      if (self.$container && self.$container.length) return self.$container;
      var sel = [
        '.widget_settings_block__body',
        '.widget-settings__body',
        '.widget_settings__body',
        '.settings__page-body',
        '#widget_settings__content'
      ];
      for (var i = 0; i < sel.length; i++) {
        var $c = $(sel[i]);
        if ($c.length) return $c;
      }
      return $('body'); // fallback extremo (não deve ser necessário)
    }

    function mount() {
      var $c = findContainer();
      // remove instância anterior, se houver
      $c.find('#widget-advanced-root').remove();
      // injeta o HTML da aba avançada
      $c.append(htmlAdvanced());
      // liga seus handlers / carrega dados
      wireStatic();
      loadDynamic();
    }

    // ========= Eventos estáticos / Dinâmicos (placeholders) =========
    function wireStatic() {
      // coloque aqui seus .on('click', ...) / listeners
      // $(document).off('click.minhaaba', '#meu-botao').on('click.minhaaba', '#meu-botao', () => { ... });
    }
    function loadDynamic() {
      // carregamentos assíncronos (ex.: $.ajax para bots/pipelines)
      // var s = getCfg(); ...
    }

    // ========= Callbacks (estrutura do modelo) =========
    this.callbacks = {
      init: function () { return true; },

      render: function () {
        try {
          var area = (self.system && typeof self.system === 'function') ? self.system().area : null;
          // exatamente como no modelo: só monta quando abrir a aba advanced_settings
          if (area === 'advanced_settings') {
            if (document.readyState === 'complete' || document.readyState === 'interactive') {
              mount();
            } else {
              var once = function () { mount(); document.removeEventListener('DOMContentLoaded', once); };
              document.addEventListener('DOMContentLoaded', once);
            }
          }
        } catch (e) {
          console.error('[Widget] render erro:', e);
        }
        return true;
      },

      bind_actions: function () { return true; },
      settings: function () { return true; },  // tela padrão (não usada aqui)
      onSave: function () { return true; },
      destroy: function () {
        // boa prática: remover handlers namespaced se você usar
        // $(document).off('.minhaaba');
      }
    };

    return this;
  };

  return CustomWidget;
});
