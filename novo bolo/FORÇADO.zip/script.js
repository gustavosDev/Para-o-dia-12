define(['jquery', 'underscore'], function ($, _) {
  var CustomWidget = function () {
    var self = this;
    var injected = false;
    var observer = null;
    var forceTimer = null, forceTries = 0;

    // ---------- Helpers ----------
    function getCfg() {
      var s = (typeof self.get_settings === 'function' ? self.get_settings() : {}) || {};
      return {
        bolo_enabled: !!s.bolo_enabled,
        entrevista_enabled: !!s.entrevista_enabled,
        tarefa_enabled: !!s.tarefa_enabled
      };
    }

    function saveCfg(partial) {
      var current = (typeof self.get_settings === 'function' ? self.get_settings() : {}) || {};
      var payload = Object.assign({}, current, partial || {});
      if (typeof self.save_settings === 'function') self.save_settings(payload);
      if (window.AMOCRM && AMOCRM.notifications) {
        AMOCRM.notifications.show_message({
          header: 'Configurações salvas',
          text: 'Preferências atualizadas com sucesso.',
          date: new Date()
        });
      }
      return payload;
    }

    // ---------- UI ----------
    function htmlAdvanced() {
      return `
        <div id="widget-advanced-root" class="kembed">
          <style>
            .kembed{font-family:Inter,system-ui,Segoe UI,Roboto,Arial,sans-serif;color:#101828}
            .kembed .panel{max-width:980px;margin:0 auto;padding:8px 0}
            .kembed .topbar{display:flex;justify-content:flex-end;gap:8px;margin-bottom:16px}
            .kembed .btn{padding:10px 14px;border:none;border-radius:10px;font-weight:600;cursor:pointer;transition:.15s}
            .kembed .btn--primary{background:#2b7cff;color:#fff}
            .kembed .btn--primary:hover{background:#1f5ec4}
            .kembed .btn--secondary{background:#f5f5f7;color:#222;border:1px solid #e6e8ee}
            .kembed .grid{display:grid;gap:16px}
            @media(min-width:900px){.kembed .grid{grid-template-columns:1fr 1fr}}
            .kembed .card{background:#fff;border:1px solid #e6e8ee;border-radius:14px;padding:18px;display:flex;flex-direction:column;gap:10px}
            .kembed .card h3{margin:0;font-size:16px;line-height:1.2}
            .kembed .desc{color:#475467;font-size:13px;line-height:1.55}
            .kembed .switch{display:inline-flex;align-items:center;gap:10px;user-select:none}
            .kembed .switch input{display:none}
            .kembed .slider{position:relative;width:46px;height:26px;background:#e5e7eb;border-radius:999px;transition:.2s}
            .kembed .switch input:checked + .slider{background:#2b7cff}
            .kembed .switch input:checked + .slider::after{transform:translateX(20px)}
            .kembed .footer{margin-top:16px;display:flex;justify-content:flex-end;gap:10px}
          </style>

          <div class="panel">
            <div class="topbar">
              <button type="button" class="btn btn--secondary" id="btn_restaurar">Restaurar padrão</button>
              <button type="button" class="btn btn--primary" id="btn_salvar">Salvar configurações</button>
            </div>

            <div class="grid">
              <div class="card">
                <div class="switch">
                  <label><input type="checkbox" id="toggle_bolo"><span class="slider"></span></label>
                  <strong>Automação “Bolo”</strong>
                </div>
                <h3>Identificar e mover leads que faltaram à visita</h3>
                <p class="desc">Verifica leads que não compareceram e move para “bolo”, criando tarefa de follow-up.</p>
              </div>

              <div class="card">
                <div class="switch">
                  <label><input type="checkbox" id="toggle_entrevista"><span class="slider"></span></label>
                  <strong>Atualização automática da data/hora da entrevista</strong>
                </div>
                <h3>Sincronizar “entrevista realizada”</h3>
                <p class="desc">Ao marcar realizada conforme previsto, atualiza o campo de data/hora efetiva.</p>
              </div>

              <div class="card">
                <div class="switch">
                  <label><input type="checkbox" id="toggle_tarefa"><span class="slider"></span></label>
                  <strong>Criar tarefa ao criar novo lead</strong>
                </div>
                <h3>Gatilho de primeiro contato</h3>
                <p class="desc">Sempre que um novo lead for criado, gera tarefa automática para atendimento rápido.</p>
              </div>
            </div>

            <div class="footer">
              <button type="button" class="btn btn--secondary" id="btn_restaurar_b">Restaurar padrão</button>
              <button type="button" class="btn btn--primary" id="btn_salvar_b">Salvar configurações</button>
            </div>
          </div>
        </div>
      `;
    }

    // Contêineres possíveis da tela de settings (ampliado)
    var CONTAINERS = [
      '#widget_settings__body',
      '.widget_settings__body',
      '.widget_settings_block__body',
      '.widget-settings__body',
      '#widget_settings__content',
      '.js-widget-settings-body',
      '.widget-settings-body',
      '.settings__page-body',
      '.settings__content',
      '.content__inner',
      '.content__body',
      '.content__page',
      '.widgets-card__content',
      '.widget-settings__wrap',
      '[data-widget-settings-body]'
    ];

    function findSettingsContainer() {
      for (var i = 0; i < CONTAINERS.length; i++) {
        var $w = $(CONTAINERS[i]);
        if ($w.length) return $w.first();
      }
      return $();
    }

    function hardMountFallback() {
      var $anchors = $('.settings__page-body, .content__inner, .settings__content, .content__body, .content__page');
      if (!$anchors.length) $anchors = $('#work-area, #content, body');
      var $host = $anchors.first();
      if (!$host.length) return false;
      if (!$('#widget-advanced-root').length) {
        $host.append(htmlAdvanced());
        console.warn('[Widget] hardMountFallback aplicado em', $host.get(0));
      }
      injected = true;
      return true;
    }

    function bindHandlers() {
      $(document).off('.widgetadv');

      function readUI() {
        return {
          bolo_enabled: $('#toggle_bolo').is(':checked'),
          entrevista_enabled: $('#toggle_entrevista').is(':checked'),
          tarefa_enabled: $('#toggle_tarefa').is(':checked')
        };
      }
      function salvar() { saveCfg(readUI()); }
      function restaurarPadrao() { $('#toggle_bolo,#toggle_entrevista,#toggle_tarefa').prop('checked', false); }

      $(document).on('click.widgetadv', '#btn_salvar, #btn_salvar_b', salvar);
      $(document).on('click.widgetadv', '#btn_restaurar, #btn_restaurar_b', restaurarPadrao);
    }

    // Injeção (para no sucesso)
    function injectUI($wrap) {
      if (!$wrap || !$wrap.length) return false;
      $wrap.find('#widget-advanced-root').remove();
      $wrap.append(htmlAdvanced());

      var cfg = getCfg();
      $('#toggle_bolo').prop('checked', cfg.bolo_enabled);
      $('#toggle_entrevista').prop('checked', cfg.entrevista_enabled);
      $('#toggle_tarefa').prop('checked', cfg.tarefa_enabled);

      bindHandlers();
      injected = true;
      console.log('[Widget] UI injetada em', $wrap.get(0));

      stopObserver();
      if (forceTimer) { clearInterval(forceTimer); forceTimer = null; }
      return true;
    }

    // Injeção agressiva perto do título “Funcionalidades Avançadas” ou “Configurações Avançadas”
    function injectNearTitle() {
      var $title = $(
        'h1:contains("Funcionalidades Avançadas"), ' +
        '.page-title:contains("Funcionalidades Avançadas"), ' +
        '.settings__title:contains("Funcionalidades Avançadas"), ' +
        '.content__title:contains("Funcionalidades Avançadas"), ' +
        'h1:contains("Configurações Avançadas"), ' +
        '.page-title:contains("Configurações Avançadas"), ' +
        '.settings__title:contains("Configurações Avançadas"), ' +
        '.content__title:contains("Configurações Avançadas")'
      ).first();
      if (!$title.length) return false;

      var $host = $title.closest('div,section,header').parent();
      if (!$host.length) $host = $title.parent();

      if (!$('#widget-advanced-root').length) {
        $host.append(htmlAdvanced());
        console.warn('[Widget] injectNearTitle aplicado');
      }
      bindHandlers();
      injected = true;

      stopObserver();
      if (forceTimer) { clearInterval(forceTimer); forceTimer = null; }
      return true;
    }

    // Observer autocicatrizante (reinjeta se sumir)
    function startObserver() {
      stopObserver();
      observer = new MutationObserver(function () {
        if (document.getElementById('widget-advanced-root')) return; // já presente
        injected = false;
        var $wrap = findSettingsContainer();
        if ($wrap.length && injectUI($wrap)) {
          stopObserver();
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
    function stopObserver() {
      if (observer) { observer.disconnect(); observer = null; }
    }

    // Brute force por 10s (200ms x 50)
    function forceMountLoop() {
      if (forceTimer) return;
      forceTries = 0;
      forceTimer = setInterval(function () {
        if (document.getElementById('widget-advanced-root')) {
          clearInterval(forceTimer); forceTimer = null;
          return;
        }
        forceTries++;

        var $wrap = findSettingsContainer();
        if ($wrap.length && injectUI($wrap)) {
          clearInterval(forceTimer); forceTimer = null;
          stopObserver();
          return;
        }

        if (injectNearTitle()) {
          clearInterval(forceTimer); forceTimer = null;
          stopObserver();
          return;
        }

        if (forceTries >= 50) {
          clearInterval(forceTimer); forceTimer = null;
          stopObserver();
        }
      }, 200);
    }

    function ensureInject() {
      var $wrap = findSettingsContainer();
      if ($wrap.length && injectUI($wrap)) {
        stopObserver();
        return;
      }
      startObserver();
      forceMountLoop();
    }

    // ============= CALLBACKS PRINCIPAIS =============
    this.callbacks = {
      render: function () {
        try {
          var area = (self.system && typeof self.system === 'function') ? self.system().area : null;
          console.log('[Widget] render area:', area);
          var isSettingsArea = (area === 'settings' || area === 'advanced_settings');
          var isWidgetsRoute = /\/settings\/widgets/i.test(location.href);
          if (isSettingsArea || isWidgetsRoute) {
            setTimeout(ensureInject, 0);
          }
        } catch (e) { console.error('[Widget] render erro:', e); }
        return true;
      },

      init: function () {
        console.log('[Widget] init');
        return true;
      },

      bind_actions: function () {
        console.log('[Widget] bind_actions');
        return true;
      },

      settings: function () {
        console.log('[Widget] settings (abrindo UI custom)');
        ensureInject();
        return true;
      },

      onSave: function () {
        var settingsData = {
          pipeline_id: $('#pipeline_id').val(),
          stage_id: $('#stage_id').val(),
          automation_enabled: $('#automation_enabled').is(':checked') ? 1 : 0
        };
        return new Promise(function (resolve, reject) {
          $.ajax({
            url: '/private/account/widget.php?action=update',
            method: 'POST',
            data: settingsData,
            dataType: 'json'
          })
          .done(function (response) { console.log('Configurações salvas:', response); resolve(true); })
          .fail(function (err) { console.error('Erro ao salvar configurações:', err); reject(false); });
        });
      },

      advancedSettings: function () {
        console.log('[Widget] advancedSettings (abrindo UI custom)');
        ensureInject();
        return true;
      },

      destroy: function () {
        console.log('[Widget] destroy');
        injected = false;
        $(document).off('.widgetadv');
        stopObserver();
        if (forceTimer) { clearInterval(forceTimer); forceTimer = null; }
      }
    };

    return this;
  };

  return CustomWidget;
});
