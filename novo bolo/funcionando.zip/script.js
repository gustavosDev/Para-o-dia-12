define(['jquery', 'underscore'], function ($, _) {
  var CustomWidget = function () {
    var self = this;

    // ---------- Helpers ----------
    function getCfg() {
      // Em muitos widgets, get_settings() já existe no contexto
      var s = (typeof self.get_settings === 'function' ? self.get_settings() : {}) || {};
      return {
        bolo_enabled: !!s.bolo_enabled,
        entrevista_enabled: !!s.entrevista_enabled,
        tarefa_enabled: !!s.tarefa_enabled
      };
    }

    function saveCfg(partial) {
      var current = (typeof self.get_settings === 'function' ? self.get_settings() : {}) || {};
      var payload = Object.assign({}, current, partial || {});
      if (typeof self.save_settings === 'function') {
        self.save_settings(payload);
      } else {
        console.warn('[Widget] save_settings não disponível. Payload:', payload);
      }
      if (window.AMOCRM && AMOCRM.notifications) {
        AMOCRM.notifications.show_message({
          header: 'Configurações salvas',
          text: 'Preferências atualizadas com sucesso.',
          date: new Date()
        });
      }
      return payload;
    }

    // ============= CALLBACKS PRINCIPAIS =============
    this.callbacks = {
      // Chamado ao abrir o widget (board, lead, etc.)
      render: function () {
        console.log('[Widget] render');
        // Ex.: ler flags e iniciar listeners globais
        var cfg = getCfg();
        console.log('[Widget] flags atuais:', cfg);
        return true;
      },

      // Chamado após render; bom para requisições iniciais
      init: function () {
        console.log('[Widget] init');
        return true;
      },

      // Bind de eventos de UI do próprio Kommo
      bind_actions: function () {
        console.log('[Widget] bind_actions');
        return true;
      },

      // Tela padrão de configurações (não a avançada)
      settings: function () {
        console.log('[Widget] settings (padrão)');
        // Se quiser, injete HTML aqui também usando #widget_settings__body
        return true;
      },

      // Salvar (quando o usuário clica em "Salvar" nas configurações)
       onSave: function() {
        // Lê os dados do formulário ou das configurações
        var settingsData = {
          pipeline_id: $('#pipeline_id').val(),
          stage_id: $('#stage_id').val(),
          automation_enabled: $('#automation_enabled').is(':checked') ? 1 : 0
        };

        // Exemplo: enviando para o backend e retornando Promise
        return new Promise(function(resolve, reject) {
          $.ajax({
            url: '/private/account/widget.php?action=update',
            method: 'POST',
            data: settingsData,
            dataType: 'json'
          })
          .done(function(response) {
            console.log('Configurações salvas:', response);
            resolve(true); // <- resolve a Promise
          })
          .fail(function(err) {
            console.error('Erro ao salvar configurações:', err);
            reject(false); // <- rejeita a Promise (mantém modal aberto)
          });
        });
      },


      // ================== CONFIGURAÇÕES AVANÇADAS ==================
      advancedSettings: function () {
        console.log('[Widget] advancedSettings');
        var settings = (typeof self.get_settings === 'function' ? self.get_settings() : {}) || {};
        var cfg = {
          bolo_enabled: !!settings.bolo_enabled,
          entrevista_enabled: !!settings.entrevista_enabled,
          tarefa_enabled: !!settings.tarefa_enabled
        };

        var $wrap = $('#widget_settings__body');
        $wrap.html(`
          <div class="kembed">
            <style>
              .kembed{font-family:Inter,system-ui,Segoe UI,Roboto,Arial,sans-serif;color:#101828}
              .kembed .panel{max-width:980px;margin:0 auto;padding:8px 0}
              .kembed .topbar{display:flex;justify-content:flex-end;gap:8px;margin-bottom:16px}
              .kembed .btn{padding:10px 14px;border:none;border-radius:10px;font-weight:600;cursor:pointer;transition:.15s}
              .kembed .btn--primary{background:#2b7cff;color:#fff}
              .kembed .btn--primary:hover{background:#1f5ec4}
              .kembed .btn--secondary{background:#f5f5f7;color:#222;border:1px solid #e6e8ee}
              .kembed .grid{display:grid;gap:16px}
              @media(min-width:900px){.kembed .grid{grid-template-columns:1fr 1fr}}
              .kembed .card{background:#fff;border:1px solid #e6e8ee;border-radius:14px;padding:18px;display:flex;flex-direction:column;gap:10px}
              .kembed .card h3{margin:0;font-size:16px;line-height:1.2}
              .kembed .desc{color:#475467;font-size:13px;line-height:1.55}
              .kembed .switch{display:inline-flex;align-items:center;gap:10px;user-select:none}
              .kembed .switch input{display:none}
              .kembed .slider{position:relative;width:46px;height:26px;background:#e5e7eb;border-radius:999px;transition:.2s}
              .kembed .slider::after{content:"";position:absolute;top:3px;left:3px;width:20px;height:20px;background:#fff;border-radius:50%;transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.15)}
              .kembed .switch input:checked + .slider{background:#2b7cff}
              .kembed .switch input:checked + .slider::after{transform:translateX(20px)}
              .kembed .footer{margin-top:16px;display:flex;justify-content:flex-end;gap:10px}
            </style>

            <div class="panel">
              <div class="topbar">
                <button type="button" class="btn btn--secondary" id="btn_restaurar">Restaurar padrão</button>
                <button type="button" class="btn btn--primary" id="btn_salvar">Salvar configurações</button>
              </div>

              <div class="grid">
                <!-- 1) Função BOLO -->
                <div class="card">
                  <div class="switch">
                    <label>
                      <input type="checkbox" id="toggle_bolo">
                      <span class="slider"></span>
                    </label>
                    <strong>Automação “Bolo”</strong>
                  </div>
                  <h3>Identificar e mover leads que faltaram à visita</h3>
                  <p class="desc">
                    Verifica leads que não compareceram à visita agendada e move para a etapa “bolo”,
                    criando uma tarefa de follow‑up.
                  </p>
                </div>

                <!-- 2) Atualização automática de entrevista -->
                <div class="card">
                  <div class="switch">
                    <label>
                      <input type="checkbox" id="toggle_entrevista">
                      <span class="slider"></span>
                    </label>
                    <strong>Atualização automática da data/hora da entrevista</strong>
                  </div>
                  <h3>Sincronizar “entrevista realizada”</h3>
                  <p class="desc">
                    Ao marcar que a entrevista ocorreu conforme previsto, atualiza o campo
                    “Data da entrevista realizada” com a data/hora efetiva.
                  </p>
                </div>

                <!-- 3) Criar tarefa em novo lead -->
                <div class="card">
                  <div class="switch">
                    <label>
                      <input type="checkbox" id="toggle_tarefa">
                      <span class="slider"></span>
                    </label>
                    <strong>Criar tarefa ao criar novo lead</strong>
                  </div>
                  <h3>Gatilho de primeiro contato/acompanhamento</h3>
                  <p class="desc">
                    Toda vez que um novo lead for criado, gera automaticamente uma tarefa para garantir atendimento rápido.
                  </p>
                </div>
              </div>

              <div class="footer">
                <button type="button" class="btn btn--secondary" id="btn_restaurar_b">Restaurar padrão</button>
                <button type="button" class="btn btn--primary" id="btn_salvar_b">Salvar configurações</button>
              </div>
            </div>
          </div>
        `);

        // Estado inicial
        $('#toggle_bolo').prop('checked', cfg.bolo_enabled);
        $('#toggle_entrevista').prop('checked', cfg.entrevista_enabled);
        $('#toggle_tarefa').prop('checked', cfg.tarefa_enabled);

        // Handlers
        function readUI() {
          return {
            bolo_enabled: $('#toggle_bolo').is(':checked'),
            entrevista_enabled: $('#toggle_entrevista').is(':checked'),
            tarefa_enabled: $('#toggle_tarefa').is(':checked')
          };
        }
        function salvar() {
          var novo = readUI();
          saveCfg(novo);
        }
        function restaurarPadrao() {
          $('#toggle_bolo, #toggle_entrevista, #toggle_tarefa').prop('checked', false);
        }

        $('#btn_salvar, #btn_salvar_b').off('click').on('click', salvar);
        $('#btn_restaurar, #btn_restaurar_b').off('click').on('click', restaurarPadrao);

        return true;
      },

      // Desmontagem (quando fecha/recua)
      destroy: function () {
        console.log('[Widget] destroy');
      }
    };

    return this;
  };

  return CustomWidget;
});